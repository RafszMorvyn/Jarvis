package com.rafsz.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        instance = this
        JarvisLog.add("Accessibility Service aktif")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Membaca layar ----------

    fun readScreen(): String {
        val root = rootInActiveWindow
            ?: return "Layar tidak terbaca (app mungkin memblokir akses, atau layar terkunci)."
        val list = mutableListOf<AccessibilityNodeInfo>()
        val out = StringBuilder()
        out.append("App: ").append(root.packageName).append('\n')
        walk(root, list, out, 0)
        nodes = list
        if (list.isEmpty()) out.append("(tidak ada elemen terbaca)\n")
        return out.toString().take(12000)
    }

    private fun walk(n: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeInfo>, out: StringBuilder, depth: Int) {
        if (list.size >= 200 || depth > 40) return

        val label = if (n.isPassword) {
            "(kolom password)"
        } else {
            listOf(n.text?.toString().orEmpty(), n.contentDescription?.toString().orEmpty())
                .filter { it.isNotBlank() }
                .joinToString(" | ")
                .take(120)
        }
        val interactive = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable

        if (n.isVisibleToUser && (label.isNotBlank() || interactive)) {
            val r = Rect()
            n.getBoundsInScreen(r)
            val flags = buildList {
                if (n.isClickable) add("klik")
                if (n.isEditable) add("input")
                if (n.isScrollable) add("scroll")
                if (n.isCheckable) add(if (n.isChecked) "tercentang" else "tidak-tercentang")
                if (!n.isEnabled) add("nonaktif")
                if (n.isFocused) add("fokus")
            }.joinToString(",")
            val cls = n.className?.toString()?.substringAfterLast('.').orEmpty()
            out.append('[').append(list.size).append("] ").append(cls)
                .append(" \"").append(label).append('"')
            if (flags.isNotEmpty()) out.append(" {").append(flags).append('}')
            out.append(" (").append(r.centerX()).append(',').append(r.centerY()).append(")\n")
            list.add(n)
        }

        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { walk(it, list, out, depth + 1) }
        }
    }

    // ---------- Aksi ----------

    suspend fun clickIndex(index: Int, long: Boolean = false): String {
        val node = nodes.getOrNull(index) ?: return "ERROR: index $index tidak ada. Panggil read_screen lagi."
        node.refresh()
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK

        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            val canDo = if (long) cur.isLongClickable else cur.isClickable
            if (canDo && cur.isEnabled) {
                if (cur.performAction(action)) return "OK: aksi pada [$index]"
                break
            }
            cur = cur.parent
            depth++
        }

        val r = Rect()
        node.getBoundsInScreen(r)
        val ok = if (long) {
            gesture(pathOf(r.centerX().toFloat(), r.centerY().toFloat()), 800)
        } else {
            tapXY(r.centerX().toFloat(), r.centerY().toFloat())
        }
        return if (ok) "OK: gesture pada [$index]" else "ERROR: gagal menekan [$index]"
    }

    suspend fun tapXY(x: Float, y: Float): Boolean = gesture(pathOf(x, y), 60)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        return gesture(p, duration.coerceIn(50, 3000))
    }

    private fun pathOf(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    private suspend fun gesture(path: Path, duration: Long): Boolean =
        suspendCancellableCoroutine { cont ->
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
                .build()
            val dispatched = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            }, null)
            if (!dispatched && cont.isActive) cont.resume(false)
        }

    fun setText(text: String, index: Int?): String {
        val target: AccessibilityNodeInfo? = if (index != null) {
            nodes.getOrNull(index)
        } else {
            rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: nodes.firstOrNull { it.isEditable }
        }
        if (target == null) return "ERROR: kolom input tidak ditemukan. Ketuk kolomnya dulu."
        if (target.isPassword) return "DITOLAK: ini kolom password. Minta user mengetik sendiri."
        target.refresh()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            "OK: teks terisi"
        } else {
            "ERROR: gagal mengisi teks"
        }
    }

    fun pressEnter(): String {
        if (Build.VERSION.SDK_INT >= 30) {
            val target = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (target != null &&
                target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            ) return "OK: enter"
        }
        return "ERROR: enter tidak bisa dikirim. Ketuk tombol cari/kirim di layar."
    }

    suspend fun scroll(direction: String): String {
        val target = nodes.firstOrNull { it.isScrollable }
        if (target != null) {
            val forward = direction == "down" || direction == "right"
            val action = if (forward) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            if (target.performAction(action)) return "OK: scroll $direction"
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val ok = when (direction) {
            "down" -> swipe(w / 2, h * 0.7f, w / 2, h * 0.3f, 350)
            "up" -> swipe(w / 2, h * 0.3f, w / 2, h * 0.7f, 350)
            "left" -> swipe(w * 0.8f, h / 2, w * 0.2f, h / 2, 350)
            else -> swipe(w * 0.2f, h / 2, w * 0.8f, h / 2, 350)
        }
        return if (ok) "OK: swipe $direction" else "ERROR: scroll gagal"
    }

    fun press(button: String): String {
        if (button == "enter") return pressEnter()
        val action = when (button) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return "ERROR: tombol tidak dikenal"
        }
        return if (performGlobalAction(action)) "OK: $button" else "ERROR: gagal menekan $button"
    }

    fun openApp(name: String): String {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
        val q = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "ERROR: app '$name' tidak ditemukan"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "ERROR: app '$name' tidak bisa dibuka"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "OK: membuka ${match.loadLabel(pm)}"
    }
}
