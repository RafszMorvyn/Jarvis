package com.rafsz.jarvis

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * "Live voice": mendengar terus-menerus (SpeechRecognizer di-restart otomatis)
 * dan membalas lewat TextToSpeech. Mikrofon dijeda saat Jarvis bicara.
 */
class VoiceEngine(
    private val ctx: Context,
    private val onUtterance: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val locale: Locale = Locale.forLanguageTag("id-ID")

    @Volatile private var running = false
    @Volatile private var speaking = false

    fun start() {
        running = true
        main.post {
            tts = TextToSpeech(ctx) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = locale
                    ttsReady = true
                } else {
                    JarvisLog.add("TTS gagal diinisialisasi")
                }
            }
            startListening()
        }
    }

    fun stop() {
        running = false
        main.post {
            recognizer?.destroy()
            recognizer = null
            tts?.stop()
            tts?.shutdown()
            tts = null
        }
    }

    fun stopSpeaking() {
        main.post { tts?.stop() }
    }

    suspend fun speak(text: String) {
        if (text.isBlank()) return
        JarvisLog.add("Jarvis: $text")
        suspendCancellableCoroutine<Unit> { cont ->
            main.post {
                val t = tts
                if (t == null || !ttsReady) {
                    if (cont.isActive) cont.resume(Unit)
                    return@post
                }
                speaking = true
                recognizer?.cancel()
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finish(cont)

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish(cont)
                })
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
            }
            cont.invokeOnCancellation { stopSpeaking() }
        }
    }

    private fun finish(cont: kotlinx.coroutines.CancellableContinuation<Unit>) {
        speaking = false
        if (cont.isActive) cont.resume(Unit)
        restart(300)
    }

    private fun startListening() {
        if (!running || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            JarvisLog.add("Speech recognition tidak tersedia di perangkat ini")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
                setRecognitionListener(listener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        recognizer?.startListening(intent)
    }

    private fun restart(delayMs: Long) {
        main.postDelayed({ startListening() }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    JarvisLog.add("Izin mikrofon belum diberikan")
                    running = false
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.cancel()
                    restart(1000)
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(200)
                else -> restart(800)
            }
        }

        override fun onResults(results: android.os.Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isNotBlank()) onUtterance(text)
            restart(250)
        }
    }
}
