package com.rafsz.jarvis

import org.json.JSONArray
import org.json.JSONObject

object Tools {

    private fun prop(type: String, desc: String, options: List<String>? = null): JSONObject =
        JSONObject().put("type", type).put("description", desc).also {
            if (options != null) it.put("enum", JSONArray(options))
        }

    private fun tool(
        name: String,
        desc: String,
        props: JSONObject = JSONObject(),
        required: List<String> = emptyList()
    ): JSONObject = JSONObject()
        .put("name", name)
        .put("description", desc)
        .put(
            "input_schema",
            JSONObject()
                .put("type", "object")
                .put("properties", props)
                .put("required", JSONArray(required))
        )

    val definitions: JSONArray = JSONArray().apply {
        put(
            tool(
                "read_screen",
                "Baca isi layar saat ini. Mengembalikan daftar elemen UI berindeks: [index] kelas \"teks\" flag (x,y)."
            )
        )
        put(
            tool(
                "tap",
                "Ketuk elemen berdasarkan index dari read_screen terbaru.",
                JSONObject().put("index", prop("integer", "Index elemen")),
                listOf("index")
            )
        )
        put(
            tool(
                "long_press",
                "Tekan lama elemen berdasarkan index.",
                JSONObject().put("index", prop("integer", "Index elemen")),
                listOf("index")
            )
        )
        put(
            tool(
                "tap_xy",
                "Ketuk koordinat layar (piksel). Pakai hanya jika elemen tidak punya index yang berguna.",
                JSONObject()
                    .put("x", prop("number", "Koordinat X"))
                    .put("y", prop("number", "Koordinat Y")),
                listOf("x", "y")
            )
        )
        put(
            tool(
                "type_text",
                "Isi teks ke kolom input. Jika index dikosongkan, pakai kolom yang sedang fokus. Tidak boleh untuk password/PIN/OTP.",
                JSONObject()
                    .put("text", prop("string", "Teks yang diketik"))
                    .put("index", prop("integer", "Index kolom input (opsional)")),
                listOf("text")
            )
        )
        put(
            tool(
                "scroll",
                "Scroll layar. down = lihat konten lebih bawah.",
                JSONObject().put("direction", prop("string", "Arah", listOf("up", "down", "left", "right"))),
                listOf("direction")
            )
        )
        put(
            tool(
                "swipe",
                "Geser jari dari satu titik ke titik lain (piksel).",
                JSONObject()
                    .put("x1", prop("number", "X awal"))
                    .put("y1", prop("number", "Y awal"))
                    .put("x2", prop("number", "X akhir"))
                    .put("y2", prop("number", "Y akhir"))
                    .put("duration_ms", prop("integer", "Durasi ms, default 350")),
                listOf("x1", "y1", "x2", "y2")
            )
        )
        put(
            tool(
                "press",
                "Tombol sistem.",
                JSONObject().put(
                    "button",
                    prop("string", "Tombol", listOf("back", "home", "recents", "notifications", "quick_settings", "enter"))
                ),
                listOf("button")
            )
        )
        put(
            tool(
                "open_app",
                "Buka aplikasi berdasarkan nama yang tampil di launcher, mis. WhatsApp, Chrome, Pengaturan.",
                JSONObject().put("name", prop("string", "Nama aplikasi")),
                listOf("name")
            )
        )
        put(
            tool(
                "wait",
                "Tunggu beberapa detik (maks 10) lalu baca layar lagi, untuk loading.",
                JSONObject().put("seconds", prop("number", "Detik")),
                listOf("seconds")
            )
        )
        put(
            tool(
                "ask_user",
                "Tanya pengguna lewat suara dan tunggu jawabannya. WAJIB dipakai untuk konfirmasi tindakan sensitif.",
                JSONObject().put("question", prop("string", "Pertanyaan singkat")),
                listOf("question")
            )
        )
    }
}
