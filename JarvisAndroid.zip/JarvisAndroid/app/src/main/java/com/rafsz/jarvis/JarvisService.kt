package com.rafsz.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class JarvisService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.rafsz.jarvis.STOP"
        private const val CHANNEL = "jarvis"
        private val STOP_WORDS = listOf("stop", "berhenti", "batal", "batalkan", "cancel")
        private val WAKE_VARIANTS = listOf("jarvis", "jervis", "yarvis")
        private const val FOLLOW_UP_WINDOW_MS = 20_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var voice: VoiceEngine? = null
    private var agent: Agent? = null
    private var job: Job? = null
    private var pendingAnswer: CompletableDeferred<String>? = null
    private var wakeWordEnabled = true
    @Volatile private var lastActive = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY

        val key = Prefs.apiKey(this)
        if (key.isBlank()) {
            JarvisLog.add("API key belum diisi")
            stopSelf()
            return START_NOT_STICKY
        }
        wakeWordEnabled = Prefs.wakeWord(this)

        goForeground()
        running = true

        val engine = VoiceEngine(this) { text -> onUtterance(text) }
        voice = engine
        agent = Agent(engine, ClaudeClient(key, Prefs.model(this))) { q -> ask(q) }
        engine.start()

        scope.launch {
            delay(1500)
            engine.speak(if (wakeWordEnabled) "Jarvis siap. Panggil namaku dulu ya." else "Jarvis siap.")
        }
        JarvisLog.add("Jarvis berjalan")
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis mendengarkan")
            .setContentText("Ketuk Stop untuk mematikan")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        ServiceCompat.startForeground(
            this, 1, notif,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
    }

    private fun onUtterance(raw: String) {
        JarvisLog.add("Dengar: $raw")

        val pending = pendingAnswer
        if (pending != null && !pending.isCompleted) {
            pending.complete(raw)
            return
        }

        val text = raw.trim()
        val lower = text.lowercase()

        if (job?.isActive == true) {
            if (STOP_WORDS.any { lower == it || lower.startsWith("$it ") }) {
                job?.cancel()
                voice?.stopSpeaking()
                JarvisLog.add("Dibatalkan oleh pengguna")
            }
            return
        }

        var command = text
        if (wakeWordEnabled) {
            val inWindow = System.currentTimeMillis() - lastActive < FOLLOW_UP_WINDOW_MS
            val hit = WAKE_VARIANTS
                .map { it to lower.indexOf(it) }
                .filter { it.second >= 0 }
                .minByOrNull { it.second }
            if (hit == null && !inWindow) return
            if (hit != null) {
                command = text.substring(hit.second + hit.first.length)
                    .trim(' ', ',', '.', '!', '?')
            }
        }

        if (command.isBlank()) {
            lastActive = System.currentTimeMillis()
            scope.launch { voice?.speak("Ya?") }
            return
        }

        job = scope.launch {
            try {
                agent?.handle(command)
            } finally {
                lastActive = System.currentTimeMillis()
            }
        }
    }

    private suspend fun ask(question: String): String {
        val d = CompletableDeferred<String>()
        pendingAnswer = d
        try {
            voice?.speak(question)
            return withTimeoutOrNull(30_000) { d.await() }
                ?: "(pengguna tidak menjawab; anggap TIDAK dan batalkan tindakan)"
        } finally {
            pendingAnswer = null
        }
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        voice?.stop()
        scope.cancel()
        JarvisLog.add("Jarvis berhenti")
        super.onDestroy()
    }
}
