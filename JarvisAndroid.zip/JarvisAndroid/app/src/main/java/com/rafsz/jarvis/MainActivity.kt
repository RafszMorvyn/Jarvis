package com.rafsz.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var etKey: EditText
    private lateinit var btnToggle: Button
    private lateinit var cbWake: CheckBox

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        scrollLog = findViewById(R.id.scrollLog)
        etKey = findViewById(R.id.etKey)
        btnToggle = findViewById(R.id.btnToggle)
        cbWake = findViewById(R.id.cbWake)

        cbWake.isChecked = Prefs.wakeWord(this)
        cbWake.setOnCheckedChangeListener { _, checked -> Prefs.setWakeWord(this, checked) }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val k = etKey.text.toString().trim()
            if (k.isEmpty()) {
                Toast.makeText(this, "API key kosong", Toast.LENGTH_SHORT).show()
            } else {
                Prefs.setApiKey(this, k)
                etKey.setText("")
                Toast.makeText(this, "Tersimpan (terenkripsi)", Toast.LENGTH_SHORT).show()
                updateStatus()
            }
        }

        findViewById<Button>(R.id.btnPerm).setOnClickListener {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(perms.toTypedArray())
        }

        findViewById<Button>(R.id.btnAcc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        btnToggle.setOnClickListener {
            if (JarvisService.running) {
                startService(Intent(this, JarvisService::class.java).setAction(JarvisService.ACTION_STOP))
            } else {
                when {
                    Prefs.apiKey(this).isBlank() ->
                        Toast.makeText(this, "Isi API key dulu", Toast.LENGTH_SHORT).show()
                    ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED ->
                        Toast.makeText(this, "Izinkan mikrofon dulu", Toast.LENGTH_SHORT).show()
                    else -> ContextCompat.startForegroundService(
                        this, Intent(this, JarvisService::class.java)
                    )
                }
            }
            tvStatus.postDelayed({ updateStatus() }, 600)
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JarvisLog.lines.collect { lines ->
                    tvLog.text = lines.joinToString("\n")
                    scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
                    updateStatus()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val hasKey = Prefs.apiKey(this).isNotBlank()
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        val acc = JarvisAccessibilityService.instance != null
        tvStatus.text = buildString {
            append(if (hasKey) "API key: tersimpan\n" else "API key: BELUM diisi\n")
            append(if (mic) "Mikrofon: OK\n" else "Mikrofon: belum diizinkan\n")
            append(if (acc) "Accessibility: aktif\n" else "Accessibility: belum aktif\n")
            append(if (JarvisService.running) "Jarvis: BERJALAN" else "Jarvis: berhenti")
        }
        btnToggle.text = if (JarvisService.running) "3. Stop Jarvis" else "3. Mulai Jarvis"
    }
}
