package com.rafsz.jarvis

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    private fun sp(ctx: Context): SharedPreferences {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            ctx,
            "jarvis_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun apiKey(ctx: Context): String = sp(ctx).getString("api_key", "") ?: ""
    fun setApiKey(ctx: Context, v: String) = sp(ctx).edit().putString("api_key", v.trim()).apply()

    fun wakeWord(ctx: Context): Boolean = sp(ctx).getBoolean("wake_word", true)
    fun setWakeWord(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("wake_word", v).apply()

    fun model(ctx: Context): String = sp(ctx).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
}
